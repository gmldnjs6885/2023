package Pk03_6;

public class IfEx5 {

	public static void main(String[] args) {

		String res;
		int d;

		res=args[0]; //�ε���
		d=Integer.parseInt(args[1]);

		System.out.println("�μ��� ������ "+args.length);
		System.out.println("res=" + res);
		System.out.println("d="+d);
	}

}
